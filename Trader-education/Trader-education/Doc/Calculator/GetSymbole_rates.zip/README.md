This API for Get the symbol Rate
## npm install

## Run 
- node client.js