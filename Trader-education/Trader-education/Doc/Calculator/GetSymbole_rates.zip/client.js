// client.js
const express = require('express');
const WebSocket = require('ws')

const app = express();

const PORT = 5000;

app.listen(PORT, (req, res) => {
    console.log(`app is listening on port ${PORT}`);
});

app.get("/getsymbolrate", function (req, res) {
    let respdata = [];
    var WebSocket = require('ws');
    try {
        const host = "api.qa01.trds.pro";
        const uuid = "358c5162-7eaf-45e3-81d9-bec48f3cf3ab";
        let url = `wss://${host}/mt4-streaming/public/socket/prices?token=${req.query.token}`;

        var ws = new WebSocket(url);
        ws.on('open', function (data) {
            ws.resume();
            let subscribe = {
                subscribe: [req.query.symbol],
                accountUUID: `MT5-${uuid}`
            }
            let message = subscribe;
            ws.emit('connect', message);
        });
        ws.on('connect', function (data) {
            setTimeout(() => {
                ws.send(JSON.stringify(data));
                ws.emit('message');
            }, 3000);
        });
        ws.on('message', function (data, flags) {
            if (data != undefined) {
                let response = JSON.parse(data.toString());
                if (response.hasOwnProperty(req.query.symbol)) {
                    respdata.push(response);
                    ws.emit('close', response);
                }
            }
        });
        ws.on("close", (data) => {
            ws.terminate();
            res.send(data);
        });
        ws.on('error', function (error) {
            console.log(error);
        });
    } catch (error) {
        console.log(error);
    }
})