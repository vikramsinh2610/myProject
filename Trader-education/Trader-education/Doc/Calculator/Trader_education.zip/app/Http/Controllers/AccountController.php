<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Models\Account;
use Illuminate\Support\Facades\Auth;
//use Auth;

class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     * create new accounts.
     * @return \Illuminate\Http\Response
     */

    /**
     * @OA\Post(
     *     path="/api/users/account/create",
     *     operationId="create",
     *     tags={"Account"},
     *      @OA\Parameter(
     *         name="account",
     *         in="query",
     *         description="The device is required",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *      @OA\Parameter(
     *         name="brandId",
     *         in="query",
     *         description="The brandId is required",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns some sample category things",
     *         @OA\JsonContent()
     *     ),
     *     @OA\Response(
     *         response="400",
     *         description="Error: Bad request. When required parameters were not supplied.",
     *     ),
     *     security={{ "apiAuth": {} }}
     * )
     */

    public function create(Request $request)
    {
        // validate incoming request 
        $user_id = Auth::user()->id;
        $this->validate($request, [
            'brandId' => 'required|string',
            'account' => 'required',
        ]);

        $headers = apache_request_headers();
        try {
            $account = new Account;
            $account->user_id = $user_id;
            $account->brandId = $request->brandId;
            $account->account = $request->account;
            $account->save();

            return response()->json([
                'status' => 'success',
                'user_role' => config('constant.USER_ROLE'),
                'data' => $account
                // 'session_id' => $headers["session_id"]
            ], 201);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Account Registration Failed!', 'error' => $e->getMessage()], 409);
        }
    }

    /**
     * Get the current Symbols
     */

    /**
     * @OA\Get(
     *     path="/api/get-symbols",
     *     operationId="getsymbols",
     *     tags={"Calculators"},
     *     @OA\Response(
     *         response="200",
     *         description="Returns some sample category things",
     *         @OA\JsonContent()
     *     ),
     *     @OA\Response(
     *         response="400",
     *         description="Error: Bad request. When required parameters were not supplied.",
     *     ),
     *     security={{ "apiAuth": {} }}
     * )
     */

    public function getsymbols()
    {
        $headers = apache_request_headers();
        // print_r($headers);
        $curl = curl_init();

        $user_data = array(
            "brandId" => "fsa",
            "device" => "API",
            "login" => config('constant.USERNAME'),
            "password" => config('constant.PASSWORD')
        );

        $user_payload = json_encode($user_data);

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.qa01.trds.pro/auth/signin',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $user_payload,
            CURLOPT_HTTPHEADER => array(
                ': ',
                ': ',
                'Content-Type: application/json',
                "User-Agent: ReqBin Curl Client/1.0",
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $res = json_decode($response);
        $Bearer_token = $res->token;
        $session_id = $res->sessionUUID;


        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.qa01.trds.pro/trading-gateway/users/MT5-deaa6868-b6ee-4f34-838d-f0aea7819b88/symbols/allowed',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                ': ',
                'Authorization: Bearer ' . $Bearer_token
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $symbole_res = json_decode($response);
        $symbole_val = array();
        foreach ($symbole_res as $res) {
            $symbole = $res->pnlConversionSymbols;
            foreach ($symbole as $value) {
                $symbole_val[] = $value->symbol;
            }
        }

        return response()->json([
            'status' => 'success',
            'user_role' => config('constant.USER_ROLE'),
            'data' => $symbole_res,
            'session_id' => $session_id
        ], 201);
    }

    /**
     * Get the current Symbols Rates
     */


    /**
     * @OA\Get(
     *     path="/api/get-symbols-rates",
     *     operationId="getsymbolsrates",
     *     tags={"Calculators"},
     *       @OA\Parameter(
     *         name="symbol",
     *         in="query",
     *         description="The symbol is required",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\Response(
     *         response="200",
     *         description="Returns some sample category things",
     *         @OA\JsonContent()
     *     ),
     *     @OA\Response(
     *         response="400",
     *         description="Error: Bad request. When required parameters were not supplied.",
     *     ),
     *     security={{ "apiAuth": {} }}
     * )
     */
    public function getsymbolsrates(Request $request)
    {
        $this->validate($request, [
            'symbol' => 'required',
        ]);
        $curl = curl_init();

        $user_data = array(
            "brandId" => "fsa",
            "device" => "API",
            "login" => config('constant.USERNAME'),
            "password" => config('constant.PASSWORD')
        );

        $user_payload = json_encode($user_data);

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.qa01.trds.pro/auth/signin',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $user_payload,
            CURLOPT_HTTPHEADER => array(
                ': ',
                ': ',
                'Content-Type: application/json',
                "User-Agent: ReqBin Curl Client/1.0",
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $res = json_decode($response);
        $Bearer_token = $res->token;
        $session_id = $res->sessionUUID;

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'http://localhost:5000/getsymbolrate?token=' . $Bearer_token . '&symbol=' . $request->symbol,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return response()->json([
            'status' => 'success',
            'user_role' => config('constant.USER_ROLE'),
            'data' => json_decode($response),
            'session_id' => $session_id
        ], 201);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function show(Account $account)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function edit(Account $account)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Account $account)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Account  $account
     * @return \Illuminate\Http\Response
     */
    public function destroy(Account $account)
    {
        //
    }
}