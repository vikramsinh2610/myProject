<?php
return [
    'USER_ROLE' => 'Admin',
    'ACCOUNT_TYPES_CYSEC' => 'CySec',
    'ACCOUNT_TYPES_FSA' => 'FSA',
    'eurCySecAccount' => 'MT5-358c5162-7eaf-45e3-81d9-bec48f3cf3ab',
    'usdCySecAccount' => 'MT5-981086fa-16ff-45c2-9680-8899265dd62a',
    'gbpCySecAccount' => 'MT5-18972039-0480-472d-9859-188b7e96025f',
    'eurFsaAccount' => 'MT5-b1605e9d-f61f-4883-84fc-da1145c4883e',
    'usdFsaAccount' => 'MT5-deaa6868-b6ee-4f34-838d-f0aea7819b88',
    'gbpFsaAccount' => 'MT5-35ebe014-2e7a-4124-826b-cec38a8013af',
    'USERNAME' => 'axiance.calculator@gmail.com',
    'PASSWORD' => 'Axiance96!'
];